^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtlesim_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.11.2 (2026-06-25)
-------------------

1.11.1 (2026-05-13)
-------------------

1.11.0 (2026-05-06)
-------------------

1.10.8 (2026-04-24)
-------------------

1.10.7 (2026-03-24)
-------------------

1.10.6 (2026-02-25)
-------------------

1.10.5 (2026-02-03)
-------------------

1.10.4 (2025-12-23)
-------------------

1.10.3 (2025-12-10)
-------------------
* fix: swap action and message file group names in CMakeLists.txt (`#186 <https://github.com/ros/ros_tutorials/issues/186>`_) (`#187 <https://github.com/ros/ros_tutorials/issues/187>`_)
* Contributors: mergify[bot]

1.10.2 (2025-10-03)
-------------------
* fix cmake deprecation (`#182 <https://github.com/ros/ros_tutorials/issues/182>`_)
* Contributors: mosfet80

1.10.1 (2025-05-26)
-------------------

1.10.0 (2025-04-25)
-------------------

1.9.2 (2024-07-09)
------------------
* Create turtlesim_msgs (`#169 <https://github.com/ros/ros_tutorials/issues/169>`_)
* Contributors: Alejandro Hernández Cordero
