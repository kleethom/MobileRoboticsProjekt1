import os
from glob import glob
from setuptools import find_packages, setup

package_name = "turtlesimAutomata"

setup(
    name=package_name,
    version="1.0.0",
    packages=find_packages(exclude=["test"]),
    data_files=[
        (
            "share/ament_index/resource_index/packages",
            ["resource/" + package_name]
        ),
        ("share/" + package_name, ["package.xml"]),
        (os.path.join("share", package_name, "launch"), glob("launch/*")),
    ],
    install_requires=["setuptools"],
    zip_safe=True,
    maintainer="Thomas Kleemayr",
    maintainer_email="kT5526@mci4me.at",
    description="ROS2 turtlesim automata assignment for Mobile Robotics.",
    license="Apache-2.0",
    extras_require={
        "test": [
            "pytest",
        ],
    },
    entry_points={
        "console_scripts": [
            "automata_node = turtlesimAutomata.automata_node:main",
        ],
    },
)